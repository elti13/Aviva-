# Aviva by Kameel — site

Two versions of the same page:

- **`index.html`** + the **`/images/`** folder — the real build. Upload both to
  the repo, keeping the folder next to the HTML. This is the one to deploy.
- **`index-standalone.html`** — every photo baked into the file as data. No
  folder needed; double-click it and the whole site appears. Good for previewing
  and emailing around, too heavy (2.3 MB) to actually ship.

If `index.html` shows grey boxes with photo names in them, the `/images/` folder
isn't sitting next to it. That's the only thing that causes it.

## Palette by section

| Section | Background |
|---|---|
| Nav bar | orange `#ECAF00`, dark text, black Order now button |
| Hero, "Featured in", "Atlanta has spoken" | white `#FAFAFA` |
| The best ingredients | warm off-white `#F2F1ED` |
| Our plates, catering, chef, locations | black `#14161A` |
| Be Aviva VIP, footer | dark green `#16321B` |

Orange `#ECAF00` carries every call to action: Order now, Order, View the full
menu, Order catering, See all locations, Join, the dish numbers, the review
stars, the rules under the hero and the ingredients, and the footer headings.

## Images in /images/

| File | Where it appears |
|---|---|
| `aviva-logo.webp` | nav + footer wordmark |
| `hero-table.jpg` | hero photograph (fixed, no rotation) |
| `plate-rosemary-chicken.webp` | dish 01 |
| `plate-salmon.webp` | dish 02 |
| `plate-chicken-shawarma.webp` | dish 03 |
| `plate-lamb-shawarma.webp` | dish 04 |
| `plate-falafel.webp` | dish 05 |
| `catering-01.jpg` | catering panel (fixed, no rotation) |
| `chef-kameel.jpg` | chef portrait |
| `location-buckhead.jpg` | locations banner (tinted in CSS) |

The five plate photos had their green studio backgrounds keyed out and are saved
as transparent WebPs, so they sit on white in the hero and on black in the menu.
Each one turns slowly on its own axis — 64 seconds a revolution, alternating
direction down the page.

The hero is a single fixed photograph, bled to the top and right edges of the
window and dropped behind the orange bar, with the headline set against near-white
on the left. Nothing in it moves.

## Changing photos

Every image is a slot declared in the HTML:

```html
<figure class="slot slot--plate" data-label="Falafel plate"
        data-rotate="plate-falafel.webp"></figure>
```

`data-rotate` is a comma-separated list of files in `/images/`. One file is
static; two or more crossfade on `data-interval` (milliseconds). Add filenames to
give any slot more photos to cycle. A missing file is skipped silently.

If you add more plate shots, key out the background first so they stay
transparent — otherwise a coloured square will show against the black menu.

Rotation and spinning both stop for anyone with "reduce motion" enabled.

## Still to point somewhere real

- Order / menu / catering links go to `avivabykameel.com` — swap for your
  ordering platform.
- The VIP form validates and confirms but doesn't post anywhere. Hook `#vipForm`
  up to your list provider; the spot is marked in the script.

## Hours, as published on avivabykameel.com

- Downtown — Mon–Fri 11 am–3 pm
- Midtown — Mon–Sat 11 am–8 pm
- Buckhead — Mon–Sat 11 am–9 pm
